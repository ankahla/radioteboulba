<?php

return [
    'site_title' => 'radioTeboulba',
];
